#include <iostream>
#include <iomanip>
#include <queue>
#include <string>
#include <math.h>
#include <ctime>

#define MAZE_SIZE 10

using namespace std;
//know start and goal
class node
{
    // current position
    int xPos;
    int yPos;
    // total distance already travelled to reach the node
    int level;
    // priority=level+remaining distance estimate
    int priority;  // smaller: higher priority

    public:
        node(int xp, int yp, int d, int p) 
            {xPos=xp; yPos=yp; level=d; priority=p;}
    
        int getxPos() const {return xPos;}
        int getyPos() const {return yPos;}
        int getLevel() const {return level;}
        int getPriority() const {return priority;}

        void updatePriority(const int & xDest, const int & yDest)
        {
             priority=level+estimate(xDest, yDest)*10; //A*
        }

        // give better priority to going strait instead of diagonally
        void nextLevel(const int & i) // i: direction
        {
             level+=(dir==8?(i%2==0?10:14):10);
        }
        
        // Estimation function for the remaining distance to the goal.
        const int & estimate(const int & xDest, const int & yDest) const
        {
            static int xd, yd, d;
            xd=xDest-xPos;
            yd=yDest-yPos;         

            // Euclidian Distance
            d=static_cast<int>(sqrt(xd*xd+yd*yd));

            // Manhattan distance
            //d=abs(xd)+abs(yd);
            
            // Chebyshev distance
            //d=max(abs(xd), abs(yd));

            return(d);
        }
}
int main()
{
	int Graph[MAZE_SIZE][MAZE_SIZE];
	
	return 0;
}

int Astar(node start,node goal)
{
	//set this to empty iniazle
	//this holds node that have already visited
	//might not need this
	int closedset = {};
	
	//set of nodes to be evaluated, hold just start to begin with
	int openset = start; 
	// Cost from start along best known path.
	ing g_score[start] = 0;
	
	// Estimated total cost from start to goal through y.
	int f_score[start] = g_score[start] + heuristic_cost_estimate(start, goal);
	//while there is somthing that can be evaluated
	//if empty no more paths so failed
	while(openset)
	{
		if(current_location == goal)
		{
			return reconstruct_path(came_from, goal)
		}
		remove current from openset
		add current to closedset
		for each neighbor in neighbor_nodes(current)
            if neighbor in closedset
				keep looping
				tentative_g_score := g_score[current] + dist_between(current,neighbor)
				best score is path
	}
	
}
//calulate cost from start to goal
int heuristic_cost_estimate(start, goal)
{

}
//find neighbors ton the curretn node at most 4

int neighbor_nodes(current)
{

	//start by checking left than up right and than down
	
}
int todolist()
{
	wrkout
	astar
	tm
	lab2,6,7,8
	320 program
	373 program
	373 hws
	
}
