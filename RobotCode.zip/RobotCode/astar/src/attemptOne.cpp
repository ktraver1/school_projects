#include "attemptOne.h"

attemptOne::attemptOne()
{
    //ctor
}

attemptOne::~attemptOne()
{
    //dtor
}
