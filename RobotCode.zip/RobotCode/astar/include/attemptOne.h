#ifndef ATTEMPTONE_H
#define ATTEMPTONE_H


class attemptOne
{
    public:
        attemptOne();
        virtual ~attemptOne();
    protected:
    private:
};

#endif // ATTEMPTONE_H
